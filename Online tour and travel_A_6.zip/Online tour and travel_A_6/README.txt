To run the project, open "index.html". 
Make sure your PC is connected to the internet.
Find the screenshots in 'Screenshots' folder.

Made by :
1. Abhimanyu Das (CSE2017/013) (11700117142)
2. Milan Hembram (CSE2017/004) (11700117096)
3. Waseem Ud Din Wani (CSE2017/005) (11700117019)
4. Rajosree Das (CSE2017/061) (11700117072)
5. Indrayudh Choudhury (CSE2017/043) (11700117107)